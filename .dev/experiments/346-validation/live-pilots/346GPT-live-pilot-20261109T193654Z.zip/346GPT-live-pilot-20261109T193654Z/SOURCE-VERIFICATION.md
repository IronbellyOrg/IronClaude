# Source verification

## Pinned repository sources
Repository verified as `https://github.com/IronbellyOrg/IronClaude`. The control object was present locally; the treatment object initially was not. Neither branch movement nor local HEAD was used as a substitute. Both exact commits were fetched into a separate disposable bare object store from the fork only, then extracted with Git archive and safe tar extraction. No existing branch or working tree was changed.

Control: `933cf3a4f5fd3e4d8cce8f69c9168a2631574179`, tree `bee0a7272aac60b68e3c522a2f06bfbf4e87eceb`. Treatment: `b36bf71cd36e53aa5002a62c40fbb27c49ed6421`, tree `9c2471addf04f8c913809d8d49ddcde0a8c1fd85`; expected tree matched. Evidence: `evidence/source-fetch.json` and `evidence/frozen-source-hashes.json`.

## Native runtime and attempts
The installed `/usr/local/bin/claude` wrapper assigns its underlying executable to `/opt/nvm/versions/node/v24.22.2/bin/claude`. Its direct-executable branch applies when `CCSESSION_LAUNCH_ID` is set. Otherwise it may invoke the ccsession launcher. This pilot did not invoke an Orca session or a ccsession shim.

1. `claude --version && claude --help`: exit 127 at the first command, with `/usr/local/bin/claude: 6: exec: /opt/nvm/versions/node/v24.22.2/bin/claude: not found`. The help command did not run. This is recorded in `evidence/initial-launch-probe.json`, transcribed from observed tool output rather than a saved raw terminal stream.
2. At 2026-11-09T19:38:35.690992Z, the explicit `--print` benign smoke attempt timed out after 30 seconds. Fresh HOME, XDG_CONFIG_HOME, CLAUDE_CONFIG_DIR and disposable working directory were used, with a pilot-specific launch marker to select the existing direct-executable branch. The runner killed/waited for the launched process on timeout. Partial stdout/stderr were not saved by the exception handler. No inference or authentication conclusion is possible from silence.

A later read-only check found the target symlink present, pointing to `../lib/node_modules/@anthropic-ai/claude-code/bin/claude.exe`, with minute-level timestamp 19:38 UTC. Package metadata then reported version `2.1.321`. The pilot did not install or repair it. Environmental change and its actor/cause are unknown. No third probe was attempted.

## Effective source selection and configuration
No control/treatment command was installed, invoked or certified as loaded. No command-shadow prevention or supported configuration/source-selection mechanism was demonstrated. No native source-equivalence result exists. Local instruction/command/style files were hashed only as a host inventory; hashes do not establish precedence. Host settings contents and credential values are excluded. The wrapper's existing inherited authentication mechanism was left in place; no authentication success is asserted and no credentials were copied into disposable homes.

No model flag was selected before the prerequisite failed. No observed model, effort, provider or exposed token/cost record exists. No plugins were enumerated as effective, and no conversation history was shared among arms because no arm started.

## Isolation and provenance limits
Control and treatment source directories, empty homes and six planned run directories are physically distinct. Evidence and budgets stayed outside the target working directory. No existing workspace was used as a target and no global install ran. Fresh-home configuration is only attempted isolation; startup/load verification never completed. The source snapshots are read-only inputs by policy, not a claim of an OS-enforced sandbox.

Important correction: `evidence/host-source-hashes.json` contains the collector annotation `UNVERIFIED: native process never started`. Only the first probe establishes failure before runtime start. For the smoke, the accurate statement is **UNVERIFIED: no successful native initialization/inference was established**. The raw annotation is retained and this correction overrides its overstatement.

## Hash inventories
`evidence/frozen-source-hashes.json` records exact candidate source bytes, including absent control-only treatment additions. `evidence/host-source-hashes.json` records host file hashes without configuration contents. `evidence/runtime-observation.json` records later package/binary identity. `manifest.json` maps the sanitized packet's files to SHA-256 digests; it excludes itself from its file list to avoid a circular digest. The archive hash is supplied separately in the publication comment.
