# Pilot limitations

## Unperformed checks
No fixture selection/validation, participant prompt freeze, substantive review, revision, endpoint audit or efficacy measurement ran. All six planned runs are NOT_STARTED, not completed failures, zero-defect results or excluded unfavorable observations. Severe defects, assurance, warnings, carry/regression counts, churn, mechanisms and unnecessary repair are unmeasured. No CI or existing fixture test was executed or counted as live evidence.

## Unknown identities and source exposure
Actual native model, effort, provider, loaded commands/styles/global instructions/plugins, authentication outcome and inference completion are unknown. Version `2.1.321` comes only from package metadata read after an environmental change. No source-selection precedence or shadow prevention was demonstrated. The coordinator read the plan index/source contract; no participants existed to receive historical conclusions, answer keys or cross-arm outputs.

## Native runtime blocker and evidence gaps
Probe 1 failed with exit 127 and a missing executable; probe 2 timed out after a coordinator-chosen 30-second wait. Partial smoke stdout/stderr were not retained, so authentication failure, inference failure and startup delay cannot be distinguished. No additional inference probe was permitted within the two-attempt accounting. The executable's later appearance demonstrates an environment change, not a repaired or validated runtime. Stable loaded-source selection, authentication and observed model identity are the missing capabilities/evidence.

The first-probe evidence is transcribed from observed tool output, not an original saved stream. Host hash inventory's `native process never started` wording overstates knowledge for the smoke; SOURCE-VERIFICATION.md explicitly corrects it. None of these gaps were concealed or converted into product findings.

## Publication completeness
Publication is PARTIAL. GitHub CLI help documents image/video attachments, not ZIP attachment support. No ZIP upload, gist, release, evidence branch, commit or external hosting was attempted. Essential text evidence and the manifest are included in numbered PR comments. The sanitized ZIP remains local with a published SHA-256, not an invented download URL.

There are no omitted reviewer, reviser, candidate, diff, finding-ledger, fixture-answer-key or endpoint-audit artifacts: none were produced. Local-only items are the disposable frozen full source snapshots, bare Git object store, empty/fresh configuration homes and packaging/helper files. They are not live efficacy evidence. Private settings contents, credentials and unrelated session transcripts are excluded. The manifest records what was included; absence of raw smoke streams remains an irrecoverable evidence gap for this run.
