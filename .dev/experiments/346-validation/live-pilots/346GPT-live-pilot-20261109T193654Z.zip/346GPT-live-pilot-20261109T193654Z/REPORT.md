# 346GPT live pilot report

## Executive finding
**BLOCKED at native preflight. NO CONCLUSION about efficacy or rollout.**

Run ID: `346GPT-live-pilot-20261109T193654Z`. This is the manually executed pilot, not CI or historical-run reanalysis. It did **not establish native target inference**. No surrogate was run.

The first launcher probe failed because its executable was missing. That executable became present later without any installation by this pilot; the single benign inference smoke attempt then timed out after 30 seconds. Two launch/capability probes were consumed. Effective source/model identity remained unverified, so no participant was dispatched.

## Scope and native versus surrogate
Only disposable setup, source freezing and preflight ran. Reviews: 0/18. Revisions: 0/12. Endpoint audits: 0/6. Fixture assessors: 0/1, not dispatched after the preflight block. No product edits, installation changes, commits, pushes, merges or deployments were performed by this pilot.

## Exact source and runtime identities
- Repository: `IronbellyOrg/IronClaude`; PR #474 verified MERGED with base `346GPT-integration`.
- Control commit: `933cf3a4f5fd3e4d8cce8f69c9168a2631574179`; tree: `bee0a7272aac60b68e3c522a2f06bfbf4e87eceb`.
- Treatment commit: `b36bf71cd36e53aa5002a62c40fbb27c49ed6421`; tree: `9c2471addf04f8c913809d8d49ddcde0a8c1fd85`, exactly the expected tree.
- Intended native runtime: Claude Code through the installed launcher. Later on-disk package metadata reports `@anthropic-ai/claude-code` version `2.1.321`; this is **not a successfully observed running version**.
- Requested model: no explicit selector chosen before the block. Observed model, effort, inference provider, tokens and cost: unknown. The coordinator's model does not establish a participant identity.
- Actually loaded commands, styles, instructions and plugins: unverified. File presence and hashes are not proof of loading.

## Design and execution
The owner specified two arms, three independent runs each, identical frozen seed, independent pre-dispatch fixture assessment, matched actual model/effort and resources, paired order C1/T1, T2/C2, C3/T3, maximum R1/F1/R2/F2/R3 with early stopping, and identical read-only endpoint audits. The intended comparison concerns the whole staged contract/brief bundle, not an isolated sentence.

Pinned Git objects were fetched into a fresh disposable bare object store, then extracted into separate source directories. Separate empty control/treatment homes and run directories were created. No downloaded scripts or installers were executed. The smoke used a fresh HOME/config location and an empty disposable working directory; credentials were not copied into that home.

Preflight blocked before a fixture, ground truth, participant prompts, assessor or actual model could be selected and frozen. `PREREGISTRATION.md` is a partial preregistration record, **not a completed frozen efficacy design**.

## Per-run results
| Planned run | Loop attempted | Reviews/fixes | Target verdict | Coordinator stop | Endpoint audit |
|---|---|---|---|---|---|
| Control 1 | No | 0/0 | Not produced | Preflight blocked | Not run |
| Treatment 1 | No | 0/0 | Not produced | Preflight blocked | Not run |
| Treatment 2 | No | 0/0 | Not produced | Preflight blocked | Not run |
| Control 2 | No | 0/0 | Not produced | Preflight blocked | Not run |
| Control 3 | No | 0/0 | Not produced | Preflight blocked | Not run |
| Treatment 3 | No | 0/0 | Not produced | Preflight blocked | Not run |

All six planned runs remain visible in `results.csv`; zero loops were attempted. Unmeasured severe defects, warnings, assurance, churn, mechanisms and carry/regression counts are **unknown, not zero**. No planned run was replaced or rerun.

## Validity issues
- Probe 1 failed before the runtime executable could start. Probe 2 timed out. The exception handler recorded the timeout but discarded any partial stdout/stderr; the exact startup stage and whether an inference request was made are unknown.
- Runtime availability changed during preflight. This prevents asserting a stable version/environment across probes and is not a product efficacy result.
- Fresh HOME/config paths do not alone prove supported source isolation. Effective command precedence, shadow prevention, instructions/plugins and inference identity remain unverified.
- The coordinator saw the plan index and source contract for logistics. No participants were dispatched, so no participant contamination or cross-arm exposure occurred.

## Quality versus boundedness
The coordinator obeyed the stop budget and consumed zero review/fix/audit slots. This is only experiment-budget compliance, **not target-loop boundedness or convergence**. Severe-defect detection, required behavior retention, false PASS, warning handling, unnecessary repairs and quality relative to control were not measured. No favorable screening prerequisite was tested.

## Supported conclusions and recommendation
**Supported:** exact source commits retrieved; expected treatment tree matched; no trustworthy native inference/source/model evidence within two launch/capability probes.

**Not supported:** superiority, equivalence, convergence, severe-defect safety, warning-only progress, savings or deployment readiness.

**Recommended next decision:** authorize a separately identified preflight-only follow-up after a stable native launcher and documented isolated source-selection/authentication route are available. Preserve this BLOCKED run and spent probes; do not reset it or automatically retry. No product repair or installation is recommended by this pilot.

Publication is **PARTIAL**: essential sanitized text, result rows and manifests are posted in PR comments, but the ZIP remains local. Inspected `gh pr comment` help supports image/video attachments, not a documented ZIP route. An archive digest is not an uploaded archive link. No external upload workaround was used.
