# Pilot preregistration status

## Freeze status
Run ID: `346GPT-live-pilot-20261109T193654Z`. PARTIAL: prepared after preflight failed and before any substantive review. No efficacy preregistration was completed, and no post-output design selection occurred because no participant was dispatched. This file must not be represented as a fully preregistered experiment.

## Owner-specified design
Two arms, three independent runs each. Control `933cf3a4f5fd3e4d8cce8f69c9168a2631574179`; treatment `b36bf71cd36e53aa5002a62c40fbb27c49ed6421`; expected treatment tree `9c2471addf04f8c913809d8d49ddcde0a8c1fd85`. Compare the complete source/brief bundles, not individual wording changes. Use identical candidate/requirements, matched tools/resources, the same actual model/effort, and no shared history or writable state.

## Inputs, participants and scheduling
Planned paired order: C1/T1, T2/C2, C3/T3. Seed, requirements, hidden answer key, assessor, participant prompts, actual model, effort and endpoint auditors: NOT SELECTED due to the prerequisite block. No fixture hashes or candidate hashes exist. No historical run was substituted.

The sole benign smoke prompt was: `Reply with exactly PILOT_CAPABILITY_OK. Do not use tools, change files, or perform a review.` It was not a substantive review and had no explicit model selector.

## Budgets and decision rules
The owner's unchanged design requires: at most two capability attempts; six loops; eighteen substantive reviews; twelve revisions; six independent endpoint audits; one fixture assessor; 45 minutes per loop; four hours overall. Each loop has R1/F1/R2/F2/R3 maximum, early stop and at most one recovery solely to retrieve an already-created output. A malformed/incomplete substantive review consumes its slot. After F2 no edits are permitted. Identity and counters survive resumes; no replacement runs, free regeneration or hidden additional review.

The proposed fixture must contain a substantiated high-consequence defect, genuine lower-severity defect and required behavior that cannot disappear by narrowing, with explicit evidence/requirements and an independently validated hidden answer key. Participants must never receive that key or prior-run conclusions.

Required measurements: native/surrogate and source/configuration validity; actual model/effort; consumed slots/time/exposed tokens/cost; separate target/coordinator/audit results; severe defects and assurance gaps; warnings and carries/regressions; gross/net edits and new mechanisms; finding-linked attribution; unauthorized extra work, severity inflation and warning-driven repair.

False PASS over confirmed severe defects or missing required behavior prevents rollout recommendation. Unknown/contaminated source or shifted-model pairs cannot support causal comparison. Missing evidence is INCOMPLETE. Boundedness alone is not convergence. A favorable screening signal requires all three valid treatment runs to meet audited quality within budget, no worse severe-defect results than matched controls, and fewer unnecessary iterations or warning-driven failures. Equal control quality/efficiency means no demonstrated incremental benefit. Mixed/insufficient evidence means NO CONCLUSION, not majority PASS. Small sample and output size do not establish reliability or rollout authority.

## Deviations and stopping disposition
Preflight stopped the study before the design freeze. A 30-second local smoke timeout was chosen before that smoke, not specified by the owner or justified as a native-runtime maximum. It is a measurement limitation, not proof that inference is impossible. Partial stdout/stderr were inadvertently not retained. The initial version probe is conservatively counted as one capability/launch attempt, followed by the benign smoke as the second; no third attempt or alternative model/runtime was used.

No delivery recovery, extra review, amendment-based rerun, fixture replacement, product repair or deployment occurred. Any future attempt requires a separately identified experiment/preflight; this record stays BLOCKED.
